document.addEventListener('DOMContentLoaded', function() {
    
    //мобильная навигация гамбургер-меню
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('nav-menu');
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', function(e) {
            e.stopPropagation();
            navMenu.classList.toggle('active');
        });
    }
    
    //настройка мобильных подменю
    if (window.innerWidth <= 480) {
        document.querySelectorAll('.nav-menu > li').forEach(item => {
            const link = item.querySelector('a');
            const submenu = item.querySelector('.submenu');
            if (submenu && link) {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    item.classList.toggle('active');
                });
            }
        });
    }
    
    //модальные окна со входом и регистрацией
    const loginModal = document.getElementById('loginModal');
    const registerModal = document.getElementById('registerModal');
    
    document.querySelectorAll('#loginBtnHeader, #loginBtnNav').forEach(btn => {
        if (btn) btn.addEventListener('click', (e) => { 
            e.preventDefault(); 
            if (loginModal) loginModal.style.display = 'block'; 
        });
    });
    
    document.querySelectorAll('#registerBtnHeader, #registerBtnNav').forEach(btn => {
        if (btn) btn.addEventListener('click', (e) => { 
            e.preventDefault(); 
            if (registerModal) registerModal.style.display = 'block'; 
        });
    });
    
    document.querySelectorAll('.close').forEach(btn => {
        btn.addEventListener('click', function() {
            const modal = this.closest('.modal');
            if (modal) modal.style.display = 'none';
        });
    });
    
    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) e.target.style.display = 'none';
    });
    
    //форма обратной связи
    const feedbackForm = document.getElementById('feedbackForm');
    if (feedbackForm) {
        feedbackForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('name')?.value;
            const email = document.getElementById('email')?.value;
            const message = document.getElementById('message')?.value;
            const msgDiv = document.getElementById('formMessage');
            
            if (!name || !email || !message) {
                if (msgDiv) msgDiv.innerHTML = '<span style="color: red;">Заполните все обязательные поля!</span>';
                return;
            }
            if (!email.includes('@')) {
                if (msgDiv) msgDiv.innerHTML = '<span style="color: red;">Введите корректный email!</span>';
                return;
            }
            
            if (msgDiv) msgDiv.innerHTML = '<span style="color: green;"><i class="fas fa-check-circle"></i> Сообщение отправлено!</span>';
            feedbackForm.reset();
            setTimeout(() => { if (msgDiv) msgDiv.innerHTML = ''; }, 5000);
        });
    }
    
    //карта
    let map = null;
    let markers = [];
    let mainMarker = null;
    
    const parkCenter = [53.688254, 23.785601];
    
    const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap',
        maxZoom: 19
    });
    
    const satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: '© Esri, Maxar',
        maxZoom: 19
    });
    
    function initMap() {
        const mapElement = document.getElementById('park-map');
        if (!mapElement) return;
        
        map = L.map('park-map').setView(parkCenter, 14);
        osmLayer.addTo(map);
        
        mainMarker = L.marker(parkCenter, {
            icon: L.divIcon({
                html: '<div style="background:#4a7c59; width:40px; height:40px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:3px solid #c8ad55; box-shadow:0 2px 10px rgba(0,0,0,0.2);"><i class="fas fa-tree" style="color:white; font-size:20px;"></i></div>',
                iconSize: [40, 40],
                className: 'park-marker'
            })
        }).addTo(map);
        mainMarker.bindPopup('<b>🌳 Лесопарк Пышки</b><br>г. Гродно, ул. Пышки').openPopup();
        
        // Убираем стандартный зум, добавляем свои кнопки
        map.zoomControl.remove();
        
        const mapContainer = document.querySelector('.map-container');
        if (mapContainer) {
            const oldBtns = mapContainer.querySelectorAll('.custom-zoom-btn');
            oldBtns.forEach(btn => btn.remove());
            
            const zoomInBtn = document.createElement('button');
            zoomInBtn.innerHTML = '<i class="fas fa-plus"></i>';
            zoomInBtn.className = 'custom-zoom-btn zoom-in';
            zoomInBtn.onclick = () => map.zoomIn();
            
            const zoomOutBtn = document.createElement('button');
            zoomOutBtn.innerHTML = '<i class="fas fa-minus"></i>';
            zoomOutBtn.className = 'custom-zoom-btn zoom-out';
            zoomOutBtn.onclick = () => map.zoomOut();
            
            mapContainer.appendChild(zoomInBtn);
            mapContainer.appendChild(zoomOutBtn);
        }
    }
    
    function switchMapType(type) {
        if (!map) return;
        map.eachLayer(layer => {
            if (layer instanceof L.TileLayer) map.removeLayer(layer);
        });
        if (type === 'osm') {
            osmLayer.addTo(map);
        } else if (type === 'satellite') {
            satelliteLayer.addTo(map);
        }
        if (mainMarker) mainMarker.bringToFront();
    }
    
    const parkObjects = {
        trails: [{coords: [53.690, 23.788], name: "Главная аллея"}],
        benches: [{coords: [53.692, 23.790], name: "Скамейка у озера"}],
        playground: [{coords: [53.687, 23.783], name: "Детская площадка"}],
        sport: [{coords: [53.685, 23.780], name: "Спортивная площадка"}],
        cafe: [{coords: [53.689, 23.786], name: "Кафе 'У Леса'"}],
        viewpoints: [{coords: [53.693, 23.792], name: "Смотровая площадка"}]
    };
    
    function showObject(type) {
        if (!map) return;
        markers.forEach(m => map.removeLayer(m));
        markers = [];
        if (parkObjects[type]) {
            parkObjects[type].forEach(obj => {
                const marker = L.marker(obj.coords).addTo(map);
                marker.bindPopup(`<b>${obj.name}</b><br>Лесопарк Пышки`);
                markers.push(marker);
            });
            if (parkObjects[type][0]) {
                map.setView(parkObjects[type][0].coords, 16);
            }
        }
    }
    
    function showAllObjects() {
        if (!map) return;
        markers.forEach(m => map.removeLayer(m));
        markers = [];
        Object.keys(parkObjects).forEach(type => {
            parkObjects[type].forEach(obj => {
                const marker = L.marker(obj.coords).addTo(map);
                marker.bindPopup(`<b>${obj.name}</b>`);
                markers.push(marker);
            });
        });
    }
    
    function hideAllObjects() {
        if (!map) return;
        markers.forEach(m => map.removeLayer(m));
        markers = [];
    }
    
    initMap();
    
    document.querySelectorAll('.map-option-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.map-option-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            switchMapType(this.getAttribute('data-maptype'));
        });
    });
    
    document.querySelectorAll('.legend-item').forEach(item => {
        item.addEventListener('click', () => {
            const objType = item.getAttribute('data-object');
            if (objType) showObject(objType);
        });
    });
    
    const showAllBtn = document.getElementById('showAllObjectsBtn');
    const hideAllBtn = document.getElementById('hideAllObjectsBtn');
    if (showAllBtn) showAllBtn.addEventListener('click', showAllObjects);
    if (hideAllBtn) hideAllBtn.addEventListener('click', hideAllObjects);
    
    //плавность
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            if (targetId && targetId !== '#' && targetId.startsWith('#')) {
                const target = document.querySelector(targetId);
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    });
    
    //обновление карты
    let resizeTimeout;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(() => {
            if (map) map.invalidateSize();
        }, 200);
    });
});