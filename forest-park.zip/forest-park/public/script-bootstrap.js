document.addEventListener('DOMContentLoaded', function() {
    
    // ========== ИНИЦИАЛИЗАЦИЯ TOOLTIP ==========
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // ========== ПОКАЗ TOAST ПРИ ЗАГРУЗКЕ ==========
    const toastEl = document.getElementById('liveToast');
    if (toastEl) {
        const toast = new bootstrap.Toast(toastEl, { autohide: true, delay: 4000 });
        toast.show();
    }
    
    // ========== ФОРМА ОБРАТНОЙ СВЯЗИ ==========
    const feedbackForm = document.getElementById('feedbackForm');
    const formMessage = document.getElementById('formMessage');
    
    if (feedbackForm) {
        feedbackForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('name')?.value;
            const email = document.getElementById('email')?.value;
            const message = document.getElementById('message')?.value;
            
            if (!name || !email || !message) {
                formMessage.innerHTML = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> Заполните все обязательные поля!</div>';
                return;
            }
            if (!email.includes('@')) {
                formMessage.innerHTML = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> Введите корректный email!</div>';
                return;
            }
            
            formMessage.innerHTML = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Сообщение отправлено!</div>';
            feedbackForm.reset();
            
            setTimeout(() => { formMessage.innerHTML = ''; }, 5000);
        });
    }
    
    // ========== КАРТА (LEAFLET) ==========
    let map = null;
    let markers = [];
    let mainMarker = null;
    
    const parkCenter = [53.688254, 23.785601];
    
    const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap',
        maxZoom: 19
    });
    
    const satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: '© Esri, Maxar',
        maxZoom: 19
    });
    
    function initMap() {
        const mapElement = document.getElementById('park-map');
        if (!mapElement) return;
        
        map = L.map('park-map').setView(parkCenter, 14);
        osmLayer.addTo(map);
        
        const customIcon = L.divIcon({
            html: '<div style="background:#4a7c59; width:40px; height:40px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:3px solid #c8ad55; box-shadow:0 2px 10px rgba(0,0,0,0.2);"><i class="fas fa-tree" style="color:white; font-size:20px;"></i></div>',
            iconSize: [40, 40],
            className: 'park-marker'
        });
        
        mainMarker = L.marker(parkCenter, { icon: customIcon }).addTo(map);
        mainMarker.bindPopup('<b>🌳 Лесопарк Пышки</b><br>г. Гродно, ул. Пышки').openPopup();
    }
    
    function switchMapType(type) {
        if (!map) return;
        map.eachLayer(layer => {
            if (layer instanceof L.TileLayer) map.removeLayer(layer);
        });
        if (type === 'osm') {
            osmLayer.addTo(map);
        } else if (type === 'satellite') {
            satelliteLayer.addTo(map);
        }
        if (mainMarker) mainMarker.bringToFront();
    }
    
    const parkObjects = {
        trails: [{coords: [53.690, 23.788], name: "Главная аллея"}],
        benches: [{coords: [53.692, 23.790], name: "Скамейка у озера"}],
        playground: [{coords: [53.687, 23.783], name: "Детская площадка"}],
        sport: [{coords: [53.685, 23.780], name: "Спортивная площадка"}],
        cafe: [{coords: [53.689, 23.786], name: "Кафе 'У Леса'"}],
        viewpoints: [{coords: [53.693, 23.792], name: "Смотровая площадка"}]
    };
    
    function showObject(type) {
        if (!map) return;
        markers.forEach(m => map.removeLayer(m));
        markers = [];
        if (parkObjects[type]) {
            parkObjects[type].forEach(obj => {
                const marker = L.marker(obj.coords).addTo(map);
                marker.bindPopup(`<b>${obj.name}</b><br>Лесопарк Пышки`);
                markers.push(marker);
            });
            if (parkObjects[type][0]) {
                map.setView(parkObjects[type][0].coords, 16);
            }
        }
    }
    
    function showAllObjects() {
        if (!map) return;
        markers.forEach(m => map.removeLayer(m));
        markers = [];
        Object.keys(parkObjects).forEach(type => {
            parkObjects[type].forEach(obj => {
                const marker = L.marker(obj.coords).addTo(map);
                marker.bindPopup(`<b>${obj.name}</b>`);
                markers.push(marker);
            });
        });
    }
    
    function hideAllObjects() {
        if (!map) return;
        markers.forEach(m => map.removeLayer(m));
        markers = [];
    }
    
    initMap();
    
    // Переключение типа карты
    document.querySelectorAll('.map-type-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.map-type-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            switchMapType(this.getAttribute('data-maptype'));
        });
    });
    
    // Легенда карты
    document.querySelectorAll('.legend-item').forEach(item => {
        item.addEventListener('click', () => {
            const objType = item.getAttribute('data-object');
            if (objType) showObject(objType);
        });
    });
    
    const showAllBtn = document.getElementById('showAllObjectsBtn');
    const hideAllBtn = document.getElementById('hideAllObjectsBtn');
    if (showAllBtn) showAllBtn.addEventListener('click', showAllObjects);
    if (hideAllBtn) hideAllBtn.addEventListener('click', hideAllObjects);
    
    // Плавная прокрутка
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            if (targetId && targetId !== '#' && targetId.startsWith('#')) {
                const target = document.querySelector(targetId);
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    });
    
    // Обновление карты
    let resizeTimeout;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(() => {
            if (map) map.invalidateSize();
        }, 200);
    });
    
    console.log('✅ Bootstrap компоненты: Navbar, Dropdown, Carousel, Tooltip, Accordion, Progress, Modal, Toast');
});