<?php
/**
 * Точка входа — ООП каталог
 */
session_start();

// Подключаем конфиг БД
require_once __DIR__ . '/../config/database.php';

// Подключаем контроллер
require_once __DIR__ . '/../app/controllers/CatalogController.php';

// Запускаем
$controller = new CatalogController($pdo);
$controller->index();
?>