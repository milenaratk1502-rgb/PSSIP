<?php
/**
 * Задание 3: Подписка на рассылку
 * Отправка подтверждения на email
 */

require_once 'PHPMailer-master/src/PHPMailer.php';
require_once 'PHPMailer-master/src/SMTP.php';
require_once 'PHPMailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $name = trim($_POST['name'] ?? 'Подписчик');
    
    if (empty($email)) {
        $error = 'Введите ваш email';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Неверный формат email';
    } else {
        // Сохраняем подписчика в файл
$subscribersFile = __DIR__ . '/../storage/subscribers.txt';
        $line = date('Y-m-d H:i:s') . '|' . $email . '|' . $name . "\n";
        file_put_contents($subscribersFile, $line, FILE_APPEND | LOCK_EX);
        
        // Отправляем письмо-подтверждение через PHPMailer
        try {
            $mail = new PHPMailer(true);
            // Настройка SMTP через Gmail
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'milenaratk1502@gmail.com';
$mail->Password = 'haxc dchm jrec rofj';
$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
$mail->Port = 587;
            $mail->setFrom('noreply@forest-park.by', 'Лесопарк Пышки');
            $mail->addAddress($email, $name);
            $mail->Subject = 'Подписка на рассылку оформлена';
            $mail->CharSet = 'UTF-8';
            $mail->isHTML(true);
            
            $mail->Body = "
                <html>
                <head><style>
                    body { font-family: Arial, sans-serif; color: #333; }
                    .container { max-width: 500px; margin: 0 auto; padding: 20px; }
                    .header { background: #4a7c59; color: white; padding: 15px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f5f5f5; padding: 20px; border-radius: 0 0 10px 10px; }
                    .btn { display: inline-block; padding: 10px 25px; background: #4a7c59; color: white; text-decoration: none; border-radius: 5px; }
                </style></head>
                <body>
                    <div class='container'>
                        <div class='header'>
                            <h2>🌳 Лесопарк Пышки</h2>
                        </div>
                        <div class='content'>
                            <h3>Здравствуйте, " . htmlspecialchars($name) . "!</h3>
                            <p>Вы успешно подписались на нашу рассылку.</p>
                            <p>Теперь вы будете получать:</p>
                            <ul>
                                <li>📢 Новости лесопарка</li>
                                <li>🌿 Анонсы мероприятий</li>
                                <li>📅 Расписание экскурсий</li>
                            </ul>
                            <p>Спасибо, что с нами!</p>
                            <br>
                            <a href='http://localhost/forest-park/главная 2.html' class='btn'>На сайт</a>
                        </div>
                    </div>
                </body>
                </html>
            ";
            
            $mail->AltBody = "Здравствуйте, $name!\nВы успешно подписались на рассылку лесопарка Пышки.\nСпасибо, что с нами!";
            
            $mail->send();
            $message = 'Подписка оформлена! На ваш email отправлено подтверждение.';
            
        } catch (Exception $e) {
            $error = 'Ошибка отправки письма: ' . $mail->ErrorInfo;
        }
    }
}

// Получаем количество подписчиков
$subscribersCount = 0;
if (file_exists(__DIR__ . '/subscribers.txt')) {
    $lines = file(__DIR__ . '/subscribers.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $subscribersCount = count($lines);
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Подписка на рассылку - Лесопарк Пышки</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #4a7c59 0%, #3d614b 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 16px;
            max-width: 500px;
            width: 100%;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            text-align: center;
        }
        .icon { font-size: 48px; margin-bottom: 15px; color: #4a7c59; }
        h1 { color: #2c3e2d; margin-bottom: 5px; font-size: 26px; }
        .subtitle { color: #6b806c; margin-bottom: 25px; font-size: 14px; }
        .form-group { margin-bottom: 18px; text-align: left; }
        label {
            display: block;
            color: #2c3e2d;
            font-weight: 500;
            margin-bottom: 5px;
            font-size: 14px;
        }
        input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e8efe3;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        input:focus { outline: none; border-color: #4a7c59; }
        .btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #4a7c59 0%, #3d614b 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(74,124,89,0.4);
        }
        .message {
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .message.success { background: #d4edda; color: #155724; }
        .message.error { background: #f8d7da; color: #721c24; }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #4a7c59;
            text-decoration: none;
        }
        .back-link:hover { text-decoration: underline; }
        .stats {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e8efe3;
            font-size: 14px;
            color: #6b806c;
        }
        .stats strong { color: #2c3e2d; font-size: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon"><i class="fas fa-envelope-open-text"></i></div>
        <h1>Подписка на рассылку</h1>
        <div class="subtitle">Будьте в курсе новостей лесопарка</div>
        
        <?php if ($message): ?>
            <div class="message success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="message error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label><i class="fas fa-user"></i> Ваше имя</label>
                <input type="text" name="name" placeholder="Иван Петров">
            </div>
            <div class="form-group">
                <label><i class="fas fa-envelope"></i> Email *</label>
                <input type="email" name="email" placeholder="example@mail.com" required>
            </div>
            <button type="submit" class="btn"><i class="fas fa-check"></i> Подписаться</button>
        </form>
        
        <div class="stats">
            <strong><?php echo $subscribersCount; ?></strong> подписчиков уже с нами
        </div>
        
        <a href="главная 2.html" class="back-link">← На главную</a>
    </div>
</body>
</html>