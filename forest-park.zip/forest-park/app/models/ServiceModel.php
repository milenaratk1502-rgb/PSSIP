<?php
/**
 * Модель для работы с услугами (ООП)
 */
class ServiceModel {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    /**
     * Получить все услуги с пагинацией, поиском, сортировкой и фильтром
     */
    public function getServices($page, $itemsPerPage, $search, $category, $sort) {
        $where = [];
        $params = [];
        
        if (!empty($search)) {
            $where[] = "name LIKE ?";
            $params[] = "%$search%";
        }
        
        if (!empty($category)) {
            $where[] = "category = ?";
            $params[] = $category;
        }
        
        $whereSql = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";
        
        switch ($sort) {
            case 'price_asc':  $order = "ORDER BY price ASC"; break;
            case 'price_desc': $order = "ORDER BY price DESC"; break;
            case 'category_asc': $order = "ORDER BY category ASC"; break;
            default: $order = "ORDER BY name ASC";
        }
        
        $offset = ($page - 1) * $itemsPerPage;
        $sql = "SELECT * FROM services $whereSql $order LIMIT $offset, $itemsPerPage";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    /**
     * Получить общее количество услуг
     */
    public function getTotalCount($search, $category) {
        $where = [];
        $params = [];
        
        if (!empty($search)) {
            $where[] = "name LIKE ?";
            $params[] = "%$search%";
        }
        
        if (!empty($category)) {
            $where[] = "category = ?";
            $params[] = $category;
        }
        
        $whereSql = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";
        $sql = "SELECT COUNT(*) FROM services $whereSql";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchColumn();
    }
    
    /**
     * Получить все категории
     */
    public function getCategories() {
        return $this->pdo->query("SELECT DISTINCT category FROM services ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
    }
}
?>