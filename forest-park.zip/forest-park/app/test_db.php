<?php
$host = '127.0.0.1'; // СТРОГО IP вместо localhost
$dbname = 'forest-park';
$username = 'root';
$password = '62121502'; // Теперь пустая строка точно сработает!


try {
    // Добавляем порт (3006 — стандартный, если меняла в OpenServer — поставь свой)
    $pdo = new PDO("mysql:host=$host;port=3306;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Подключение к MySQL успешно!<br>";
    
    // Имя базы с дефисом ОБЯЗАТЕЛЬНО в косых кавычках ` `
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `forest-park`");
    echo "База данных создана!<br>";
    
} catch(PDOException $e) {
    echo "Ошибка: " . $e->getMessage();
}
?>
