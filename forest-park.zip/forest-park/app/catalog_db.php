<?php
/**
 * Каталог услуг лесопарка
 * С пагинацией, поиском, сортировкой и фильтром
 */
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/../PHPMailer-master/src/PHPMailer.php';

// Количество товаров на странице
$itemsPerPage = 4;

// Получаем параметры фильтрации
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'name_asc';
$category = isset($_GET['category']) ? $_GET['category'] : '';

// Строим запрос
$where = [];
$params = [];

if (!empty($search)) {
    $where[] = "name LIKE ?";
    $params[] = "%$search%";
}

if (!empty($category)) {
    $where[] = "category = ?";
    $params[] = $category;
}

$whereSql = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";

// Сортировка
switch ($sort) {
    case 'price_asc':
        $order = "ORDER BY price ASC";
        break;
    case 'price_desc':
        $order = "ORDER BY price DESC";
        break;
    case 'category_asc':
        $order = "ORDER BY category ASC";
        break;
    default:
        $order = "ORDER BY name ASC";
}

// Получаем общее количество товаров
$countSql = "SELECT COUNT(*) FROM services $whereSql";
$stmt = $pdo->prepare($countSql);
$stmt->execute($params);
$totalItems = $stmt->fetchColumn();
$totalPages = ceil($totalItems / $itemsPerPage);

// Получаем товары для текущей страницы
$offset = ($page - 1) * $itemsPerPage;
$sql = "SELECT * FROM services $whereSql $order LIMIT $offset, $itemsPerPage";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$services = $stmt->fetchAll();

// Получаем все категории для фильтра
$categories = $pdo->query("SELECT DISTINCT category FROM services ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);

// Корзина
$cart = $_SESSION['cart'] ?? [];
$cartCount = array_sum(array_column($cart, 'quantity'));
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Услуги - Лесопарк Пышки</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f4f8;
            padding: 20px;
        }
        .container { max-width: 1200px; margin: 0 auto; }
        
        /* Шапка */
        .header {
            background: linear-gradient(135deg, #4a7c59 0%, #3d614b 100%);
            color: white;
            padding: 20px 30px;
            border-radius: 16px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .header h1 { font-size: 28px; display: flex; align-items: center; gap: 10px; }
        .header a {
            color: white;
            text-decoration: none;
            padding: 8px 20px;
            background: rgba(255,255,255,0.2);
            border-radius: 8px;
            transition: all 0.3s;
        }
        .header a:hover { background: rgba(255,255,255,0.3); }
        .cart-badge {
            background: #ffc107;
            color: #333;
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
        }
        
        /* Фильтры */
        .filters {
            background: white;
            padding: 20px 25px;
            border-radius: 16px;
            margin-bottom: 25px;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: center;
        }
        .filters input, .filters select {
            padding: 8px 15px;
            border: 2px solid #e8efe3;
            border-radius: 8px;
            font-size: 14px;
        }
        .filters input:focus, .filters select:focus {
            outline: none;
            border-color: #4a7c59;
        }
        .filters input { flex: 1; min-width: 150px; }
        .filters button {
            padding: 8px 20px;
            background: #4a7c59;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .filters button:hover { background: #3d614b; }
        .filters .reset-btn { background: #888; }
        .filters .reset-btn:hover { background: #666; }
        
        /* Карточки товаров */
        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 20px;
        }
        .service-card {
            background: white;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s;
            display: flex;
            flex-direction: column;
        }
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        .service-card .category {
            font-size: 12px;
            color: #888;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .service-card h3 {
            color: #2c3e2d;
            margin: 5px 0 8px;
            font-size: 18px;
        }
        .service-card .desc {
            color: #666;
            font-size: 14px;
            flex: 1;
            margin-bottom: 10px;
        }
        .service-card .price {
            font-size: 22px;
            font-weight: 700;
            color: #4a7c59;
        }
        .service-card .actions {
            display: flex;
            gap: 10px;
            margin-top: 12px;
        }
        .service-card .btn-cart {
            flex: 1;
            padding: 8px 15px;
            background: linear-gradient(135deg, #4a7c59 0%, #3d614b 100%);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 14px;
        }
        .service-card .btn-cart:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(74,124,89,0.3);
        }
        .service-card .btn-cart.in-cart {
            background: #ffc107;
            color: #333;
        }
        
        /* Пагинация */
        .pagination {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin: 30px 0;
            flex-wrap: wrap;
        }
        .pagination a {
            padding: 8px 16px;
            background: white;
            border-radius: 8px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s;
        }
        .pagination a:hover { background: #e8efe3; }
        .pagination a.active {
            background: #4a7c59;
            color: white;
        }
        
        .no-results {
            text-align: center;
            color: #888;
            padding: 40px 0;
        }
        .no-results .icon { font-size: 48px; display: block; margin-bottom: 15px; }
        
        @media (max-width: 600px) {
            .header { flex-direction: column; text-align: center; }
            .filters { flex-direction: column; }
            .filters input { width: 100%; }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Шапка -->
        <div class="header">
            <h1><i class="fas fa-tree"></i> Услуги лесопарка</h1>
            <div>
                <a href="cart.php"><i class="fas fa-shopping-cart"></i> Корзина <span class="cart-badge"><?php echo $cartCount; ?></span></a>
                <a href="../public/главная 2.html"><i class="fas fa-home"></i> На главную</a>
            </div>
        </div>
        
        <!-- Фильтры -->
        <form class="filters" method="GET">
            <input type="text" name="search" placeholder="Поиск услуг..." value="<?php echo htmlspecialchars($search); ?>">
            <select name="category">
                <option value="">Все категории</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo htmlspecialchars($cat); ?>" <?php echo $category == $cat ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($cat); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <select name="sort">
                <option value="name_asc" <?php echo $sort == 'name_asc' ? 'selected' : ''; ?>>По названию ↑</option>
                <option value="price_asc" <?php echo $sort == 'price_asc' ? 'selected' : ''; ?>>По цене ↑</option>
                <option value="price_desc" <?php echo $sort == 'price_desc' ? 'selected' : ''; ?>>По цене ↓</option>
                <option value="category_asc" <?php echo $sort == 'category_asc' ? 'selected' : ''; ?>>По категории</option>
            </select>
            <button type="submit"><i class="fas fa-search"></i> Применить</button>
            <a href="catalog_db.php" class="reset-btn" style="padding:8px 20px; background:#888; color:white; border-radius:8px; text-decoration:none;">Сбросить</a>
        </form>
        
        <!-- Результаты -->
        <?php if (empty($services)): ?>
            <div class="no-results">
                <span class="icon"><i class="fas fa-search"></i></span>
                <p>Услуги не найдены. Попробуйте изменить параметры поиска.</p>
            </div>
        <?php else: ?>
            <div class="services-grid">
                <?php foreach ($services as $service): ?>
                    <div class="service-card">
                        <div class="category"><i class="fas fa-tag"></i> <?php echo htmlspecialchars($service['category']); ?></div>
                        <h3><?php echo htmlspecialchars($service['name']); ?></h3>
                        <div class="desc"><?php echo htmlspecialchars($service['description']); ?></div>
                        <div class="price"><?php echo number_format($service['price'], 2); ?> руб.</div>
                        <div class="actions">
                            <button class="btn-cart" data-id="<?php echo $service['id']; ?>" data-name="<?php echo htmlspecialchars($service['name']); ?>" data-price="<?php echo $service['price']; ?>">
                                <i class="fas fa-plus"></i> В корзину
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Пагинация -->
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search); ?>&sort=<?php echo $sort; ?>&category=<?php echo urlencode($category); ?>">← Назад</a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&sort=<?php echo $sort; ?>&category=<?php echo urlencode($category); ?>" class="<?php echo $i == $page ? 'active' : ''; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                    
                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search); ?>&sort=<?php echo $sort; ?>&category=<?php echo urlencode($category); ?>">Вперёд →</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.btn-cart').forEach(function(button) {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                const id = this.dataset.id;
                const name = this.dataset.name;
                const price = this.dataset.price;
                
                fetch('cart.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        id: id,
                        name: name,
                        price: price,
                        action: 'add'
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Обновляем счётчик
                        const badge = document.querySelector('.cart-badge');
                        if (badge) {
                            badge.textContent = data.count;
                        }
                        // Меняем текст кнопки
                        this.innerHTML = '<i class="fas fa-check"></i> В корзине';
                        this.classList.add('in-cart');
                    } else {
                        alert('Ошибка добавления');
                    }
                })
                .catch(error => {
                    console.error('Ошибка:', error);
                    alert('Ошибка сети');
                });
            });
        });
    });
    </script>
</body>
</html>