<?php
header("Location: главная 2.html");
exit;
?>