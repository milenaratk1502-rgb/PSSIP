<?php
/**
 * Контроллер каталога (ООП)
 */
require_once __DIR__ . '/../models/ServiceModel.php';

class CatalogController {
    private $serviceModel;
    private $cartCount;
    
    public function __construct($pdo) {
        $this->serviceModel = new ServiceModel($pdo);
        $this->cartCount = $this->getCartCount();
    }
    
private function getCartCount() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $cart = $_SESSION['cart'] ?? [];
    return array_sum(array_column($cart, 'quantity'));
}
    
    public function index() {
        $itemsPerPage = 4;
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $search = isset($_GET['search']) ? trim($_GET['search']) : '';
        $sort = isset($_GET['sort']) ? $_GET['sort'] : 'name_asc';
        $category = isset($_GET['category']) ? $_GET['category'] : '';
        
        $totalItems = $this->serviceModel->getTotalCount($search, $category);
        $totalPages = ceil($totalItems / $itemsPerPage);
        $services = $this->serviceModel->getServices($page, $itemsPerPage, $search, $category, $sort);
        $categories = $this->serviceModel->getCategories();
        
        // Передаём данные в представление
        $data = [
            'services' => $services,
            'categories' => $categories,
            'totalPages' => $totalPages,
            'currentPage' => $page,
            'search' => $search,
            'sort' => $sort,
            'category' => $category,
            'cartCount' => $this->cartCount,
            'itemsPerPage' => $itemsPerPage
        ];
        
        // Подключаем View
        require_once __DIR__ . '/../views/catalog.php';
    }
}
?>