<?php
/**
 * Оформление заказа
 */
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/../PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/../PHPMailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$cart = $_SESSION['cart'] ?? [];
$total = 0;
foreach ($cart as $item) {
    $total += $item['price'] * $item['quantity'];
}

if (empty($cart)) {
    header('Location: catalog_db.php');
    exit;
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $comment = trim($_POST['comment'] ?? '');
    
    if (empty($name) || empty($email) || empty($phone)) {
        $error = 'Заполните все обязательные поля!';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Неверный формат email!';
    } else {
        try {
            // Сохраняем заказ в БД
            $stmt = $pdo->prepare("INSERT INTO orders (name, email, phone, comment, total, items) VALUES (?, ?, ?, ?, ?, ?)");
            $itemsJson = json_encode($cart);
            $stmt->execute([$name, $email, $phone, $comment, $total, $itemsJson]);
            $orderId = $pdo->lastInsertId();
            
            // Отправляем письмо
            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'milenaratk1502@gmail.com';
            $mail->Password = 'haxc dchm jrec rofj';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
            
            $mail->setFrom('noreply@forest-park.by', 'Лесопарк Пышки');
            $mail->addAddress($email, $name);
            $mail->addAddress('milenaratk1502@gmail.com', 'Милена');
            $mail->Subject = 'Заказ #' . $orderId . ' - Лесопарк Пышки';
            $mail->CharSet = 'UTF-8';
            $mail->isHTML(true);
            
            $itemsHtml = '';
            foreach ($cart as $id => $item) {
                $itemsHtml .= "<tr><td>" . htmlspecialchars($item['name']) . "</td><td>" . $item['quantity'] . "</td><td>" . number_format($item['price'], 2) . " руб.</td></tr>";
            }
            
            $mail->Body = "
                <html>
                <head><style>
                    body { font-family: Arial, sans-serif; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: #4a7c59; color: white; padding: 15px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f5f5f5; padding: 20px; border-radius: 0 0 10px 10px; }
                    table { width: 100%; border-collapse: collapse; }
                    th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
                </style></head>
                <body>
                    <div class='container'>
                        <div class='header'><h2>Заказ #$orderId</h2></div>
                        <div class='content'>
                            <p><strong>Клиент:</strong> " . htmlspecialchars($name) . "</p>
                            <p><strong>Email:</strong> " . htmlspecialchars($email) . "</p>
                            <p><strong>Телефон:</strong> " . htmlspecialchars($phone) . "</p>
                            <p><strong>Комментарий:</strong> " . htmlspecialchars($comment ?: 'Нет') . "</p>
                            <hr>
                            <table>
                                <tr><th>Услуга</th><th>Кол-во</th><th>Сумма</th></tr>
                                $itemsHtml
                                <tr><td colspan='2'><strong>Итого</strong></td><td><strong>" . number_format($total, 2) . " руб.</strong></td></tr>
                            </table>
                        </div>
                    </div>
                </body>
                </html>
            ";
            
            $mail->AltBody = "Заказ #$orderId\nКлиент: $name\nEmail: $email\nТелефон: $phone\n\nИтого: $total руб.";
            $mail->send();
            
            // Очищаем корзину
            $_SESSION['cart'] = [];
            $message = 'Заказ оформлен! Подтверждение отправлено на email.';
            
        } catch (Exception $e) {
            $error = 'Ошибка: ' . $mail->ErrorInfo;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Оформление заказа - Лесопарк Пышки</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f4f8;
            padding: 20px;
        }
        .container { max-width: 600px; margin: 0 auto; }
        .header {
            background: linear-gradient(135deg, #4a7c59 0%, #3d614b 100%);
            color: white;
            padding: 20px 30px;
            border-radius: 16px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .header h1 { font-size: 28px; display: flex; align-items: center; gap: 10px; }
        .header a {
            color: white;
            text-decoration: none;
            padding: 8px 20px;
            background: rgba(255,255,255,0.2);
            border-radius: 8px;
            transition: all 0.3s;
        }
        .header a:hover { background: rgba(255,255,255,0.3); }
        
        .form-section {
            background: white;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .form-group { margin-bottom: 18px; }
        label {
            display: block;
            color: #2c3e2d;
            font-weight: 500;
            margin-bottom: 5px;
        }
        input, textarea {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e8efe3;
            border-radius: 8px;
            font-size: 15px;
            font-family: inherit;
        }
        input:focus, textarea:focus {
            outline: none;
            border-color: #4a7c59;
        }
        textarea { resize: vertical; min-height: 80px; }
        .btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #4a7c59 0%, #3d614b 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(74,124,89,0.3);
        }
        .message {
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .message.success { background: #d4edda; color: #155724; }
        .message.error { background: #f8d7da; color: #721c24; }
        .order-summary {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .order-summary p { padding: 3px 0; color: #555; }
        .order-summary .total { font-weight: 700; color: #4a7c59; font-size: 18px; }
        .required { color: #e53935; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-check-circle"></i> Оформление заказа</h1>
            <a href="cart.php"><i class="fas fa-arrow-left"></i> Назад в корзину</a>
        </div>
        
        <?php if ($message): ?>
            <div class="message success"><?php echo htmlspecialchars($message); ?></div>
            <div style="text-align:center; margin-top:20px;">
                <a href="catalog_db.php" class="btn" style="display:inline-block; padding:12px 30px; background:#4a7c59; color:white; text-decoration:none; border-radius:8px;">Продолжить покупки</a>
            </div>
        <?php else: ?>
            <div class="form-section">
                <?php if ($error): ?>
                    <div class="message error"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                
                <div class="order-summary">
                    <p><strong>Ваш заказ:</strong></p>
                    <?php foreach ($cart as $item): ?>
                        <p><?php echo htmlspecialchars($item['name']); ?> × <?php echo $item['quantity']; ?> = <?php echo number_format($item['price'] * $item['quantity'], 2); ?> руб.</p>
                    <?php endforeach; ?>
                    <p class="total">Итого: <?php echo number_format($total, 2); ?> руб.</p>
                </div>
                
                <form method="POST">
                    <div class="form-group">
                        <label>Имя <span class="required">*</span></label>
                        <input type="text" name="name" required placeholder="Иван Петров">
                    </div>
                    <div class="form-group">
                        <label>Email <span class="required">*</span></label>
                        <input type="email" name="email" required placeholder="example@mail.com">
                    </div>
                    <div class="form-group">
                        <label>Телефон <span class="required">*</span></label>
                        <input type="tel" name="phone" required placeholder="+375 (00) 000-00-00">
                    </div>
                    <div class="form-group">
                        <label>Комментарий к заказу</label>
                        <textarea name="comment" placeholder="Ваши пожелания..."></textarea>
                    </div>
                    <button type="submit" class="btn"><i class="fas fa-paper-plane"></i> Подтвердить заказ</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>