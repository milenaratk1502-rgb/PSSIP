<?php
/**
 * Задание 3: Обратная связь
 * Отправка письма администратору
 */
require_once __DIR__ . '/../PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/../PHPMailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $text = trim($_POST['message'] ?? '');
    
    if (empty($name) || empty($email) || empty($text)) {
        $error = 'Заполните все обязательные поля!';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Неверный формат email!';
    } else {
        // Сохраняем в файл
$feedbackFile = __DIR__ . '/../storage/feedback.txt';
        $line = date('Y-m-d H:i:s') . '|' . $name . '|' . $email . '|' . $subject . '|' . str_replace("\n", ' ', $text) . "\n";
        file_put_contents($feedbackFile, $line, FILE_APPEND | LOCK_EX);
        
        // Отправляем письмо администратору
        try {
            $mail = new PHPMailer(true);
              // Настройка SMTP через Gmail
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'milenaratk1502@gmail.com';
$mail->Password = 'haxc dchm jrec rofj';
$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
$mail->Port = 587;
            $mail->setFrom($email, $name);
$mail->addAddress('milenaratk1502@gmail.com', 'Милена');
            $mail->addReplyTo($email, $name);
            $mail->Subject = 'Новое сообщение с сайта: ' . ($subject ?: 'Без темы');
            $mail->CharSet = 'UTF-8';
            $mail->isHTML(true);
            
            $mail->Body = "
                <html>
                <head><style>
                    body { font-family: Arial, sans-serif; color: #333; }
                    .container { max-width: 500px; margin: 0 auto; padding: 20px; }
                    .header { background: #4a7c59; color: white; padding: 15px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f5f5f5; padding: 20px; border-radius: 0 0 10px 10px; }
                </style></head>
                <body>
                    <div class='container'>
                        <div class='header'><h2>📩 Новое сообщение</h2></div>
                        <div class='content'>
                            <p><strong>От:</strong> " . htmlspecialchars($name) . "</p>
                            <p><strong>Email:</strong> " . htmlspecialchars($email) . "</p>
                            <p><strong>Тема:</strong> " . htmlspecialchars($subject ?: 'Без темы') . "</p>
                            <hr>
                            <p><strong>Сообщение:</strong></p>
                            <p>" . nl2br(htmlspecialchars($text)) . "</p>
                            <hr>
                            <p style='color:#888; font-size:12px;'>Отправлено с сайта Лесопарк Пышки</p>
                        </div>
                    </div>
                </body>
                </html>
            ";
            
            $mail->AltBody = "Новое сообщение от: $name\nEmail: $email\n\nСообщение:\n$text";
            
            $mail->send();
            $message = 'Ваше сообщение отправлено! Спасибо за обратную связь.';
            
        } catch (Exception $e) {
            $error = 'Ошибка отправки: ' . $mail->ErrorInfo;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Обратная связь - Лесопарк Пышки</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #4a7c59 0%, #3d614b 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 16px;
            max-width: 550px;
            width: 100%;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .icon { font-size: 48px; text-align: center; margin-bottom: 15px; color: #4a7c59; }
        h1 { color: #2c3e2d; text-align: center; margin-bottom: 5px; font-size: 26px; }
        .subtitle { color: #6b806c; text-align: center; margin-bottom: 25px; font-size: 14px; }
        .form-group { margin-bottom: 18px; }
        label {
            display: block;
            color: #2c3e2d;
            font-weight: 500;
            margin-bottom: 5px;
            font-size: 14px;
        }
        input, textarea, select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e8efe3;
            border-radius: 8px;
            font-size: 16px;
            font-family: inherit;
            transition: border-color 0.3s;
        }
        input:focus, textarea:focus { outline: none; border-color: #4a7c59; }
        textarea { resize: vertical; min-height: 100px; }
        .btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #4a7c59 0%, #3d614b 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(74,124,89,0.4);
        }
        .message {
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .message.success { background: #d4edda; color: #155724; }
        .message.error { background: #f8d7da; color: #721c24; }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #4a7c59;
            text-decoration: none;
        }
        .back-link:hover { text-decoration: underline; }
        .required { color: #e53935; }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon"><i class="fas fa-comment-dots"></i></div>
        <h1>Обратная связь</h1>
        <div class="subtitle">Напишите нам — мы ответим в ближайшее время</div>
        
        <?php if ($message): ?>
            <div class="message success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="message error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label><i class="fas fa-user"></i> Ваше имя <span class="required">*</span></label>
                <input type="text" name="name" placeholder="Иван Петров" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-envelope"></i> Email <span class="required">*</span></label>
                <input type="email" name="email" placeholder="example@mail.com" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-tag"></i> Тема</label>
                <input type="text" name="subject" placeholder="Вопрос, предложение, жалоба...">
            </div>
            <div class="form-group">
                <label><i class="fas fa-comment"></i> Сообщение <span class="required">*</span></label>
                <textarea name="message" placeholder="Ваше сообщение..." required></textarea>
            </div>
            <button type="submit" class="btn"><i class="fas fa-paper-plane"></i> Отправить</button>
        </form>
        
        <a href="../public/главная 2.html" class="back-link">← На главную</a>
    </div>
</body>
</html>