<?php
header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Включим вывод ошибок для отладки
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Подключаем конфиг
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получаем RAW данные
    $input = file_get_contents('php://input');
    error_log("Raw input: " . $input);
    
    $data = json_decode($input, true);
    
    if (!$data) {
        error_log("JSON decode failed");
        echo json_encode(['success' => false, 'message' => 'Неверные данные JSON!']);
        exit;
    }
    
    $name = trim($data['name'] ?? '');
    $email = trim($data['email'] ?? '');
    $phone = trim($data['phone'] ?? '');
    $password = $data['password'] ?? '';
    
    error_log("Данные: name=$name, email=$email, phone=$phone");
    
    // Валидация
    if (empty($name) || empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Заполните все обязательные поля!']);
        exit;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Неверный формат email!']);
        exit;
    }
    
    try {
        // Проверяем, существует ли пользователь с таким email
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $existingUser = $stmt->fetch();
        
        if ($existingUser) {
            echo json_encode(['success' => false, 'message' => 'Пользователь с таким email уже существует!']);
            exit;
        }
        
        // Хешируем пароль
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // Вставляем нового пользователя
        $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $email, $phone, $hashedPassword]);
        
        $userId = $pdo->lastInsertId();
        
        $response = [
            'success' => true, 
            'message' => 'Регистрация успешна!',
            'user' => [
                'id' => $userId,
                'name' => $name,
                'email' => $email,
                'phone' => $phone
            ]
        ];
        
        error_log("Успешная регистрация в БД: " . json_encode($response));
        echo json_encode($response);
        
    } catch(PDOException $e) {
        error_log("Ошибка БД: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Ошибка базы данных: ' . $e->getMessage()]);
    }
    
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса! Используйте POST.']);
}
?>