<?php
$host = 'localhost';
$username = 'forest_user';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host", $username, $password);
    echo "✅ ПОДКЛЮЧЕНО!<br>";
    echo "Пользователь: forest_user<br>";
    echo "Версия MySQL: " . $pdo->query("SELECT VERSION()")->fetchColumn();
} catch(PDOException $e) {
    echo "❌ Ошибка: " . $e->getMessage();
}
?>