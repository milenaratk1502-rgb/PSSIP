<?php
echo "=== ДИАГНОСТИКА ПОДКЛЮЧЕНИЯ К MySQL ===<br><br>";

// 1. Проверяем, какой ini-файл использует PHP
echo "1. php.ini используется: " . php_ini_loaded_file() . "<br><br>";

// 2. Пробуем подключиться через localhost
echo "2. Пробуем localhost:<br>";
try {
    $pdo = new PDO("mysql:host=localhost;port=3306", 'root', '');
    echo "✅ root с пустым паролем - УСПЕШНО!<br>";
} catch (PDOException $e) {
    echo "❌ root с пустым: " . $e->getMessage() . "<br>";
}
try {
    $pdo = new PDO("mysql:host=localhost;port=3306", 'root', 'root');
    echo "✅ root с паролем 'root' - УСПЕШНО!<br>";
} catch (PDOException $e) {
    echo "❌ root с 'root': " . $e->getMessage() . "<br>";
}
try {
    $pdo = new PDO("mysql:host=localhost;port=3306", 'forest_user', '');
    echo "✅ forest_user с пустым - УСПЕШНО!<br>";
} catch (PDOException $e) {
    echo "❌ forest_user с пустым: " . $e->getMessage() . "<br>";
}
echo "<br>";

// 3. Пробуем подключиться через 127.0.0.1
echo "3. Пробуем 127.0.0.1 (другой хост):<br>";
try {
    $pdo = new PDO("mysql:host=127.0.0.1;port=3306", 'root', '');
    echo "✅ root с пустым (127.0.0.1) - УСПЕШНО!<br>";
} catch (PDOException $e) {
    echo "❌ root с пустым (127.0.0.1): " . $e->getMessage() . "<br>";
}
try {
    $pdo = new PDO("mysql:host=127.0.0.1;port=3306", 'root', 'root');
    echo "✅ root с 'root' (127.0.0.1) - УСПЕШНО!<br>";
} catch (PDOException $e) {
    echo "❌ root с 'root' (127.0.0.1): " . $e->getMessage() . "<br>";
}
?>