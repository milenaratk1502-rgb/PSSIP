<?php
/**
 * Задание 3: Отправка анкеты на email
 */
require_once __DIR__ . '/../PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/../PHPMailer-master/src/Exception.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$message = '';
$error = '';
$anketaData = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $anketaData = [
        'name' => trim($_POST['name'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''),
        'age' => trim($_POST['age'] ?? ''),
        'visit_date' => trim($_POST['visit_date'] ?? ''),
        'rating' => trim($_POST['rating'] ?? ''),
        'like' => trim($_POST['like'] ?? ''),
        'comment' => trim($_POST['comment'] ?? '')
    ];
    
    $errors = [];
    if (empty($anketaData['name'])) $errors[] = 'Имя обязательно';
    if (empty($anketaData['email'])) $errors[] = 'Email обязателен';
    elseif (!filter_var($anketaData['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Неверный email';
    
    if (empty($errors)) {
        try {
            $mail = new PHPMailer(true);
            
            // ===== НАСТРОЙКА SMTP (GMAIL) =====
            // Настройка SMTP через Gmail
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'milenaratk1502@gmail.com';
$mail->Password = 'haxc dchm jrec rofj';
$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
$mail->Port = 587;
            // ===================================
            
            $mail->setFrom($anketaData['email'], $anketaData['name']);
$mail->addAddress('milenaratk1502@gmail.com', 'Милена');
            $mail->Subject = 'Новая анкета посетителя';
            $mail->CharSet = 'UTF-8';
            $mail->isHTML(true);
            
            $ratingLabels = ['1' => '⭐', '2' => '⭐⭐', '3' => '⭐⭐⭐', '4' => '⭐⭐⭐⭐', '5' => '⭐⭐⭐⭐⭐'];
            
            $mail->Body = "
                <html>
                <head><style>
                    body { font-family: Arial, sans-serif; color: #333; }
                    .container { max-width: 500px; margin: 0 auto; padding: 20px; }
                    .header { background: #4a7c59; color: white; padding: 15px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f5f5f5; padding: 20px; border-radius: 0 0 10px 10px; }
                    .field { margin: 8px 0; padding: 8px; background: white; border-radius: 5px; }
                    .label { font-weight: 600; color: #4a7c59; }
                </style></head>
                <body>
                    <div class='container'>
                        <div class='header'><h2>📋 Анкета посетителя</h2></div>
                        <div class='content'>
                            <div class='field'><span class='label'>Имя:</span> " . htmlspecialchars($anketaData['name']) . "</div>
                            <div class='field'><span class='label'>Email:</span> " . htmlspecialchars($anketaData['email']) . "</div>
                            <div class='field'><span class='label'>Телефон:</span> " . htmlspecialchars($anketaData['phone'] ?: 'Не указан') . "</div>
                            <div class='field'><span class='label'>Возраст:</span> " . htmlspecialchars($anketaData['age'] ?: 'Не указан') . "</div>
                            <div class='field'><span class='label'>Дата посещения:</span> " . htmlspecialchars($anketaData['visit_date'] ?: 'Не указана') . "</div>
                            <div class='field'><span class='label'>Оценка:</span> " . ($ratingLabels[$anketaData['rating']] ?? 'Не указана') . "</div>
                            <div class='field'><span class='label'>Что понравилось:</span> " . htmlspecialchars($anketaData['like'] ?: 'Не указано') . "</div>
                            <div class='field'><span class='label'>Комментарий:</span><br>" . nl2br(htmlspecialchars($anketaData['comment'] ?: 'Нет')) . "</div>
                            <hr>
                            <p style='color:#888; font-size:12px;'>Отправлено с сайта Лесопарк Пышки</p>
                        </div>
                    </div>
                </body>
                </html>
            ";
            
            $mail->AltBody = "Анкета посетителя\nИмя: {$anketaData['name']}\nEmail: {$anketaData['email']}\nТелефон: {$anketaData['phone']}\nОценка: {$anketaData['rating']}\nКомментарий: {$anketaData['comment']}";
            
            $mail->send();
            $message = 'Анкета успешно отправлена! Спасибо за обратную связь.';
            $anketaData = [];
            
        } catch (Exception $e) {
            $error = 'Ошибка отправки: ' . $mail->ErrorInfo;
        }
    } else {
        $error = implode('<br>', $errors);
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Анкета посетителя - Лесопарк Пышки</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #4a7c59 0%, #3d614b 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 16px;
            max-width: 600px;
            width: 100%;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .icon { font-size: 48px; text-align: center; margin-bottom: 15px; color: #4a7c59; }
        h1 { color: #2c3e2d; text-align: center; margin-bottom: 5px; font-size: 26px; }
        .subtitle { color: #6b806c; text-align: center; margin-bottom: 25px; font-size: 14px; }
        .form-group { margin-bottom: 18px; }
        label {
            display: block;
            color: #2c3e2d;
            font-weight: 500;
            margin-bottom: 5px;
            font-size: 14px;
        }
        input, textarea, select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e8efe3;
            border-radius: 8px;
            font-size: 16px;
            font-family: inherit;
            transition: border-color 0.3s;
        }
        input:focus, textarea:focus, select:focus { outline: none; border-color: #4a7c59; }
        textarea { resize: vertical; min-height: 80px; }
        .btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #4a7c59 0%, #3d614b 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(74,124,89,0.4);
        }
        .message {
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .message.success { background: #d4edda; color: #155724; }
        .message.error { background: #f8d7da; color: #721c24; }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #4a7c59;
            text-decoration: none;
        }
        .back-link:hover { text-decoration: underline; }
        .required { color: #e53935; }
        .rating-group {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .rating-group label {
            display: flex;
            align-items: center;
            gap: 5px;
            font-weight: normal;
            cursor: pointer;
            padding: 5px 12px;
            border-radius: 20px;
            border: 2px solid #e8efe3;
            transition: all 0.3s;
        }
        .rating-group label:hover { border-color: #4a7c59; }
        .rating-group input[type="radio"] { display: none; }
        .rating-group label:has(input:checked) {
            border-color: #4a7c59;
            background: #e8f5e9;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon"><i class="fas fa-clipboard-list"></i></div>
        <h1>Анкета посетителя</h1>
        <div class="subtitle">Помогите нам стать лучше</div>
        
        <?php if ($message): ?>
            <div class="message success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="message error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label><i class="fas fa-user"></i> Имя <span class="required">*</span></label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($anketaData['name'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-envelope"></i> Email <span class="required">*</span></label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($anketaData['email'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-phone"></i> Телефон</label>
                <input type="tel" name="phone" value="<?php echo htmlspecialchars($anketaData['phone'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label><i class="fas fa-calendar"></i> Ваш возраст</label>
                <select name="age">
                    <option value="">Выберите</option>
                    <option value="до 18" <?php echo (($anketaData['age'] ?? '') == 'до 18') ? 'selected' : ''; ?>>до 18</option>
                    <option value="18-25" <?php echo (($anketaData['age'] ?? '') == '18-25') ? 'selected' : ''; ?>>18-25</option>
                    <option value="26-35" <?php echo (($anketaData['age'] ?? '') == '26-35') ? 'selected' : ''; ?>>26-35</option>
                    <option value="36-50" <?php echo (($anketaData['age'] ?? '') == '36-50') ? 'selected' : ''; ?>>36-50</option>
                    <option value="51+" <?php echo (($anketaData['age'] ?? '') == '51+') ? 'selected' : ''; ?>>51+</option>
                </select>
            </div>
            <div class="form-group">
                <label><i class="fas fa-calendar-day"></i> Дата посещения</label>
                <input type="date" name="visit_date" value="<?php echo htmlspecialchars($anketaData['visit_date'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label><i class="fas fa-star"></i> Оцените лесопарк</label>
                <div class="rating-group">
                    <label><input type="radio" name="rating" value="1" <?php echo (($anketaData['rating'] ?? '') == '1') ? 'checked' : ''; ?>> ⭐</label>
                    <label><input type="radio" name="rating" value="2" <?php echo (($anketaData['rating'] ?? '') == '2') ? 'checked' : ''; ?>> ⭐⭐</label>
                    <label><input type="radio" name="rating" value="3" <?php echo (($anketaData['rating'] ?? '') == '3') ? 'checked' : ''; ?>> ⭐⭐⭐</label>
                    <label><input type="radio" name="rating" value="4" <?php echo (($anketaData['rating'] ?? '') == '4') ? 'checked' : ''; ?>> ⭐⭐⭐⭐</label>
                    <label><input type="radio" name="rating" value="5" <?php echo (($anketaData['rating'] ?? '') == '5' || empty($anketaData['rating'])) ? 'checked' : ''; ?>> ⭐⭐⭐⭐⭐</label>
                </div>
            </div>
            <div class="form-group">
                <label><i class="fas fa-heart"></i> Что понравилось больше всего?</label>
                <input type="text" name="like" value="<?php echo htmlspecialchars($anketaData['like'] ?? ''); ?>" placeholder="Например: природа, маршруты, тишина...">
            </div>
            <div class="form-group">
                <label><i class="fas fa-comment"></i> Ваши пожелания</label>
                <textarea name="comment" placeholder="Что мы можем улучшить?"><?php echo htmlspecialchars($anketaData['comment'] ?? ''); ?></textarea>
            </div>
            <button type="submit" class="btn"><i class="fas fa-paper-plane"></i> Отправить анкету</button>
        </form>
        
        <a href="../public/главная 2.html" class="back-link">← На главную</a>
    </div>
</body>
</html>