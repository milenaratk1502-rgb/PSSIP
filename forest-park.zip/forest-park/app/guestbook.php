<?php
/**
 * Задание 2: Гостевая книга - Отзывы посетителей лесопарка
 */

$reviewsFile = __DIR__ . '/../storage/reviews.txt';

// Если файла нет - создаём с примерами
if (!file_exists($reviewsFile)) {
    $sampleData = "Иван Петров|20.06.2025|5|Отличное место для прогулок! Природа шикарная.\n";
    $sampleData .= "Мария Иванова|21.06.2025|4|Очень понравилась экотропа.\n";
    $sampleData .= "Алексей Смирнов|22.06.2025|5|Хорошо, что есть такие места для отдыха.\n";
    file_put_contents($reviewsFile, $sampleData);
}

$message = '';
$error = '';

// Обработка отправки нового отзыва
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {
    $name = trim($_POST['name'] ?? '');
    $review = trim($_POST['review'] ?? '');
    $rating = (int)($_POST['rating'] ?? 5);
    
    if (empty($name)) {
        $error = 'Введите ваше имя';
    } elseif (empty($review)) {
        $error = 'Введите текст отзыва';
    } else {
        $date = date('d.m.Y');
        $line = $name . '|' . $date . '|' . $rating . '|' . $review . "\n";
        
        if (file_put_contents($reviewsFile, $line, FILE_APPEND | LOCK_EX)) {
            $message = 'Спасибо за ваш отзыв!';
        } else {
            $error = 'Ошибка при сохранении отзыва';
        }
    }
}

// Чтение всех отзывов из файла
$reviews = [];
if (file_exists($reviewsFile)) {
    $content = file_get_contents($reviewsFile);
    
    // Если файл не пустой
    if ($content !== false && trim($content) !== '') {
        $lines = explode("\n", trim($content));
        
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;
            
            $parts = explode('|', $line);
            
            // Проверяем, что все части есть
            if (count($parts) >= 4) {
                $reviews[] = [
                    'name' => htmlspecialchars(trim($parts[0])),
                    'date' => htmlspecialchars(trim($parts[1])),
                    'rating' => (int)trim($parts[2]),
                    'text' => htmlspecialchars(trim($parts[3]))
                ];
            }
        }
    }
}

// Переворачиваем, чтобы новые были сверху
$reviews = array_reverse($reviews);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Гостевая книга - Лесопарк Пышки</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f4f8;
            padding: 30px 20px;
            min-height: 100vh;
        }
        .container { max-width: 800px; margin: 0 auto; }
        .header {
            background: linear-gradient(135deg, #4a7c59 0%, #3d614b 100%);
            color: white;
            padding: 25px 30px;
            border-radius: 16px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .header h1 {
            font-size: 28px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .header h1 i { color: #ffc107; }
        .header .back-link {
            color: white;
            text-decoration: none;
            padding: 8px 20px;
            background: rgba(255,255,255,0.2);
            border-radius: 8px;
            transition: all 0.3s;
        }
        .header .back-link:hover { background: rgba(255,255,255,0.3); }
        
        .form-section {
            background: white;
            padding: 25px 30px;
            border-radius: 16px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }
        .form-section h2 {
            color: #2c3e2d;
            margin-bottom: 18px;
            font-size: 20px;
        }
        .form-section h2 i { color: #4a7c59; margin-right: 10px; }
        .form-group { margin-bottom: 15px; }
        .form-group label {
            display: block;
            color: #2c3e2d;
            font-weight: 500;
            margin-bottom: 5px;
            font-size: 14px;
        }
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 10px 14px;
            border: 2px solid #e8efe3;
            border-radius: 8px;
            font-size: 15px;
            transition: border-color 0.3s;
            font-family: inherit;
        }
        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #4a7c59;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }
        .rating-group {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .rating-group label {
            display: flex;
            align-items: center;
            gap: 5px;
            font-weight: normal;
            cursor: pointer;
            padding: 5px 12px;
            border-radius: 20px;
            border: 2px solid #e8efe3;
            transition: all 0.3s;
        }
        .rating-group label:hover { border-color: #4a7c59; }
        .rating-group input[type="radio"] { display: none; }
        .rating-group label:has(input:checked) {
            border-color: #4a7c59;
            background: #e8f5e9;
        }
        .btn-submit {
            padding: 12px 30px;
            background: linear-gradient(135deg, #4a7c59 0%, #3d614b 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(74,124,89,0.4);
        }
        .message {
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        .message.success { background: #d4edda; color: #155724; }
        .message.error { background: #f8d7da; color: #721c24; }
        
        .reviews-section {
            background: white;
            padding: 25px 30px;
            border-radius: 16px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .reviews-section h2 {
            color: #2c3e2d;
            margin-bottom: 18px;
            font-size: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .reviews-section h2 span {
            font-size: 14px;
            color: #6b806c;
            font-weight: normal;
        }
        .review-item {
            padding: 15px 0;
            border-bottom: 1px solid #e8efe3;
        }
        .review-item:last-child { border-bottom: none; }
        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
            flex-wrap: wrap;
            gap: 5px;
        }
        .review-name {
            font-weight: 600;
            color: #2c3e2d;
            font-size: 16px;
        }
        .review-date {
            color: #6b806c;
            font-size: 13px;
        }
        .review-stars {
            color: #ffc107;
            font-size: 16px;
            letter-spacing: 2px;
            margin-bottom: 5px;
        }
        .review-text {
            color: #444;
            line-height: 1.6;
            font-size: 15px;
        }
        .empty-reviews {
            text-align: center;
            color: #6b806c;
            padding: 30px 0;
        }
        .empty-reviews .big-icon {
            font-size: 48px;
            display: block;
            margin-bottom: 10px;
            color: #e8efe3;
        }
        @media (max-width: 600px) {
            .header { flex-direction: column; text-align: center; }
            .form-section, .reviews-section { padding: 20px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-comment-dots"></i> Гостевая книга</h1>
            <div>
                <span style="margin-right:15px; font-size:14px; opacity:0.8;">
                    <i class="fas fa-edit"></i> Оставьте свой отзыв
                </span>
                <a href="../public/главная 2.html" class="back-link"><i class="fas fa-arrow-left"></i> На главную</a>
            </div>
        </div>
        
        <div class="form-section">
            <h2><i class="fas fa-pen"></i> Написать отзыв</h2>
            
            <?php if ($message): ?>
                <div class="message success"><?php echo $message; ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="message error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Ваше имя</label>
                    <input type="text" name="name" placeholder="Например: Иван Петров" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-star"></i> Оценка</label>
                    <div class="rating-group">
                        <label><input type="radio" name="rating" value="1"> ⭐</label>
                        <label><input type="radio" name="rating" value="2"> ⭐⭐</label>
                        <label><input type="radio" name="rating" value="3"> ⭐⭐⭐</label>
                        <label><input type="radio" name="rating" value="4" checked> ⭐⭐⭐⭐</label>
                        <label><input type="radio" name="rating" value="5"> ⭐⭐⭐⭐⭐</label>
                    </div>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-comment"></i> Текст отзыва</label>
                    <textarea name="review" placeholder="Поделитесь впечатлениями о посещении лесопарка..." required></textarea>
                </div>
                <button type="submit" name="submit_review" class="btn-submit">
                    <i class="fas fa-paper-plane"></i> Отправить отзыв
                </button>
            </form>
        </div>
        
        <div class="reviews-section">
            <h2>
                <span><i class="fas fa-list"></i> Отзывы посетителей</span>
            </h2>
            
            <?php if (empty($reviews)): ?>
                <div class="empty-reviews">
                    <span class="big-icon"><i class="fas fa-comment-slash"></i></span>
                    Пока нет отзывов. Будьте первым!
                </div>
            <?php else: ?>
                <?php foreach ($reviews as $review): ?>
                    <div class="review-item">
                        <div class="review-header">
                            <span class="review-name"><?php echo $review['name']; ?></span>
                            <span class="review-date"><?php echo $review['date']; ?></span>
                        </div>
                        <div class="review-stars">
                            <?php 
                            $full = $review['rating'];
                            $empty = 5 - $full;
                            echo str_repeat('★', $full);
                            echo str_repeat('☆', $empty);
                            ?>
                        </div>
                        <div class="review-text"><?php echo $review['text']; ?></div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>