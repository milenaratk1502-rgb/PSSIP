<?php
/**
 * Создание таблиц для каталога услуг
 */
require_once 'config.php';

try {
    // ===== ТАБЛИЦА УСЛУГ =====
    $pdo->exec("CREATE TABLE IF NOT EXISTS services (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        price DECIMAL(10,2) NOT NULL,
        category VARCHAR(50) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    echo "✅ Таблица 'services' создана!<br>";
    
    // ===== ТАБЛИЦА ЗАКАЗОВ =====
    $pdo->exec("CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        comment TEXT,
        total DECIMAL(10,2) NOT NULL,
        items TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    echo "✅ Таблица 'orders' создана!<br>";
    
    // Проверяем, есть ли уже услуги
    $stmt = $pdo->query("SELECT COUNT(*) FROM services");
    $count = $stmt->fetchColumn();
    
    if ($count == 0) {
        // Добавляем услуги
        $services = [
            ['Экскурсия "Тропа сов"', 'Ночная экскурсия с наблюдением за совами', 25.00, 'Экскурсии'],
            ['Экскурсия "Тропой древних дубов"', 'Познавательная экскурсия по старым дубам', 20.00, 'Экскурсии'],
            ['Экскурсия "История лесопарка"', 'Рассказ об истории парка и его обитателях', 15.00, 'Экскурсии'],
            ['Аренда беседки (малая)', 'Уютная беседка на 6 человек', 15.00, 'Аренда'],
            ['Аренда беседки (большая)', 'Просторная беседка на 12 человек с мангалом', 30.00, 'Аренда'],
            ['Прокат велосипеда (взрослый)', 'Горный велосипед для взрослых', 10.00, 'Прокат'],
            ['Прокат велосипеда (детский)', 'Детский велосипед с защитой', 7.00, 'Прокат'],
            ['Прокат роликов', 'Роликовые коньки для взрослых и детей', 8.00, 'Прокат'],
            ['Мастер-класс по фотографии', 'Учимся фотографировать природу', 15.00, 'Мастер-классы'],
            ['Мастер-класс по оригами', 'Создаём фигурки из бумаги на природе', 10.00, 'Мастер-классы'],
            ['Мастер-класс по плетению венков', 'Плетём венки из полевых цветов', 12.00, 'Мастер-классы'],
            ['Пикник-набор', 'Набор для пикника: плед, посуда, салфетки', 18.00, 'Аренда'],
        ];
        
        $stmt = $pdo->prepare("INSERT INTO services (name, description, price, category) VALUES (?, ?, ?, ?)");
        
        foreach ($services as $service) {
            $stmt->execute($service);
        }
        
        echo "✅ Добавлено " . count($services) . " услуг!<br>";
    } else {
        echo "ℹ️ Услуги уже добавлены (" . $count . " шт.)<br>";
    }
    
    echo "<br>🎉 ВСЁ ГОТОВО!";
    
} catch(PDOException $e) {
    die("❌ Ошибка: " . $e->getMessage());
}
?>