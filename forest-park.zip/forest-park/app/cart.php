<?php
/**
 * Корзина покупок (сессии)
 */
session_start();

// Инициализация корзины
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Обработка AJAX-запросов (добавление в корзину)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $action = $data['action'] ?? '';
    
    if ($action === 'add') {
        $id = (int)$data['id'];
        $name = $data['name'];
        $price = (float)$data['price'];
        
        if (!isset($_SESSION['cart'][$id])) {
            $_SESSION['cart'][$id] = [
                'name' => $name,
                'price' => $price,
                'quantity' => 0
            ];
        }
        $_SESSION['cart'][$id]['quantity']++;
        
        $totalCount = array_sum(array_column($_SESSION['cart'], 'quantity'));
        echo json_encode(['success' => true, 'count' => $totalCount]);
        exit;
    }
    
    if ($action === 'remove') {
        $id = (int)$data['id'];
        if (isset($_SESSION['cart'][$id])) {
            unset($_SESSION['cart'][$id]);
        }
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($action === 'update') {
        $id = (int)$data['id'];
        $quantity = (int)$data['quantity'];
        if ($quantity <= 0) {
            unset($_SESSION['cart'][$id]);
        } else {
            $_SESSION['cart'][$id]['quantity'] = $quantity;
        }
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($action === 'clear') {
        $_SESSION['cart'] = [];
        echo json_encode(['success' => true]);
        exit;
    }
}

$cart = $_SESSION['cart'];
$total = 0;
foreach ($cart as $item) {
    $total += $item['price'] * $item['quantity'];
}
$itemsCount = array_sum(array_column($cart, 'quantity'));
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Корзина - Лесопарк Пышки</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f4f8;
            padding: 20px;
        }
        .container { max-width: 800px; margin: 0 auto; }
        .header {
            background: linear-gradient(135deg, #4a7c59 0%, #3d614b 100%);
            color: white;
            padding: 20px 30px;
            border-radius: 16px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .header h1 { font-size: 28px; display: flex; align-items: center; gap: 10px; }
        .header a {
            color: white;
            text-decoration: none;
            padding: 8px 20px;
            background: rgba(255,255,255,0.2);
            border-radius: 8px;
            transition: all 0.3s;
        }
        .header a:hover { background: rgba(255,255,255,0.3); }
        
        .cart-item {
            background: white;
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }
        .cart-item .info { flex: 1; }
        .cart-item .name { font-weight: 600; color: #2c3e2d; }
        .cart-item .price { color: #4a7c59; font-weight: 600; }
        .cart-item input {
            width: 50px;
            padding: 5px;
            border: 2px solid #e8efe3;
            border-radius: 6px;
            text-align: center;
        }
        .cart-item .remove {
            background: #e53935;
            color: white;
            border: none;
            padding: 5px 12px;
            border-radius: 6px;
            cursor: pointer;
        }
        .cart-item .remove:hover { background: #c62828; }
        
        .total {
            background: white;
            padding: 20px;
            border-radius: 12px;
            text-align: right;
            font-size: 22px;
            font-weight: 700;
            color: #2c3e2d;
        }
        .total span { color: #4a7c59; }
        
        .actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        .actions .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .actions .btn-primary {
            background: linear-gradient(135deg, #4a7c59 0%, #3d614b 100%);
            color: white;
        }
        .actions .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(74,124,89,0.3);
        }
        .actions .btn-danger {
            background: #e53935;
            color: white;
        }
        .actions .btn-danger:hover { background: #c62828; }
        .empty {
            text-align: center;
            padding: 60px 0;
            color: #888;
        }
        .empty .icon { font-size: 64px; display: block; margin-bottom: 15px; }
        
        @media (max-width: 600px) {
            .cart-item { flex-direction: column; text-align: center; }
            .actions { justify-content: center; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-shopping-cart"></i> Корзина</h1>
            <a href="catalog_db.php"><i class="fas fa-arrow-left"></i> Продолжить покупки</a>
        </div>
        
        <?php if (empty($cart)): ?>
            <div class="empty">
                <span class="icon"><i class="fas fa-shopping-basket"></i></span>
                <h2>Корзина пуста</h2>
                <p>Добавьте услуги из каталога</p>
                <a href="catalog_db.php" class="btn btn-primary" style="margin-top:15px; display:inline-block; padding:12px 25px; background:#4a7c59; color:white; border-radius:8px; text-decoration:none;">Перейти в каталог</a>
            </div>
        <?php else: ?>
            <?php foreach ($cart as $id => $item): ?>
                <div class="cart-item" data-id="<?php echo $id; ?>">
                    <div class="info">
                        <div class="name"><?php echo htmlspecialchars($item['name']); ?></div>
                        <div class="price"><?php echo number_format($item['price'], 2); ?> руб.</div>
                    </div>
                    <div>
                        <input type="number" value="<?php echo $item['quantity']; ?>" min="1" onchange="updateCart(<?php echo $id; ?>, this.value)">
                        <button class="remove" onclick="removeFromCart(<?php echo $id; ?>)"><i class="fas fa-trash"></i></button>
                    </div>
                </div>
            <?php endforeach; ?>
            
            <div class="total">
                Итого: <span><?php echo number_format($total, 2); ?> руб.</span>
            </div>
            
            <div class="actions">
                <a href="checkout.php" class="btn btn-primary"><i class="fas fa-check"></i> Оформить заказ</a>
                <button class="btn btn-danger" onclick="clearCart()"><i class="fas fa-trash"></i> Очистить корзину</button>
            </div>
        <?php endif; ?>
    </div>
    
    <script>
        function updateCart(id, quantity) {
            fetch('cart.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: id, quantity: parseInt(quantity), action: 'update' })
            })
            .then(response => response.json())
            .then(() => location.reload());
        }
        
        function removeFromCart(id) {
            if (confirm('Удалить товар из корзины?')) {
                fetch('cart.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: id, action: 'remove' })
                })
                .then(response => response.json())
                .then(() => location.reload());
            }
        }
        
        function clearCart() {
            if (confirm('Очистить корзину?')) {
                fetch('cart.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'clear' })
                })
                .then(response => response.json())
                .then(() => location.reload());
            }
        }
    </script>
</body>
</html>